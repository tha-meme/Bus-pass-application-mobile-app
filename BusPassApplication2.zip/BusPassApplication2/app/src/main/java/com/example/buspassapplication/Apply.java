package com.example.buspassapplication;

public class Apply {
    private String name;
    private String collegeName;
    private String gender;
    private String from;
    private String to;
    private int year;
    private int aadhaarNo;
    private int mobileNo;
    private String imageURL;

    public Apply() {
        // Default constructor required for Firebase
    }

    public Apply(String name, String collegeName, String gender, String from, String to, int year, int aadhaarNo, int mobileNo) {
        this.name = name;
        this.collegeName = collegeName;
        this.gender = gender;
        this.from = from;
        this.to = to;
        this.year = year;
        this.aadhaarNo = aadhaarNo;
        this.mobileNo = mobileNo;
        this.imageURL=imageURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getAadhaarNo() {
        return aadhaarNo;
    }

    public void setAadhaarNo(int aadhaarNo) {
        this.aadhaarNo = aadhaarNo;
    }

    public int getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(int mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }
}