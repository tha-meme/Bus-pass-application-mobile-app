package com.example.buspassapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class SelectPassActivity extends AppCompatActivity {
    CardView newPass_btn,currentPass_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_pass);
        newPass_btn=findViewById(R.id.new_pass);
        currentPass_btn=findViewById(R.id.current_pass);
        newPass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SelectPassActivity.this,ApplyActivity.class));
            }
        });
        currentPass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SelectPassActivity.this,currentPassActivity.class));
            }
        });
    }
}