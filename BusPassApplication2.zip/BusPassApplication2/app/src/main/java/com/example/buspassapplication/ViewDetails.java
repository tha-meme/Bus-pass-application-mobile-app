package com.example.buspassapplication;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
public class ViewDetails extends AppCompatActivity {
    private DatabaseReference databaseRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_details);

        databaseRef = FirebaseDatabase.getInstance().getReference(); // Initialize the database reference

        retrieveChildNodeNames(); // Call the method to retrieve and display child node names
    }

    private void retrieveChildNodeNames() {
        databaseRef.child("ApplyData").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String previousChildName) {
                String childNodeName = dataSnapshot.getKey();
                String name= dataSnapshot.child("name").getValue(String.class);


                // Retrieve the TableLayout container
                TableLayout tableLayoutContainer = findViewById(R.id.tableLayoutContainer);

                // Create a new TableRow
                TableRow tableRow = new TableRow(ViewDetails.this);
                tableRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));


                View separator = new View(ViewDetails.this);
                separator.setLayoutParams(new TableRow.LayoutParams(2, TableRow.LayoutParams.MATCH_PARENT)); // Adjust the width as needed
                separator.setBackgroundColor(getResources().getColor(R.color.black));

                // Create a TextView for the child node name
                TextView textViewChildNode = new TextView(ViewDetails.this);
                textViewChildNode.setText(name);
                textViewChildNode.setTextSize(24);
                textViewChildNode.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                textViewChildNode.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1));

                Button buttonViewDetails = new Button(ViewDetails.this);
                buttonViewDetails.setText("View Details");

                buttonViewDetails.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT));


                tableRow.addView(textViewChildNode);
                tableRow.addView(separator);
                tableRow.addView(buttonViewDetails);

                tableLayoutContainer.addView(tableRow);
                View horizontalLine = new View(ViewDetails.this);
                horizontalLine.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, 2)); // Adjust the height as needed
                horizontalLine.setBackgroundColor(getResources().getColor(R.color.black));
                tableLayoutContainer.addView(horizontalLine);

                buttonViewDetails.setOnClickListener(view -> {

                    databaseRef.child("ApplyData").child(childNodeName).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                            Apply apply = dataSnapshot.getValue(Apply.class);
                            String imageURL = apply.getImageURL();

                            Intent intent = new Intent(ViewDetails.this, DisplayDetails.class);
                            // Pass the data as extras
                            intent.putExtra("name", apply.getName());
                            intent.putExtra("college", apply.getCollegeName());
                            intent.putExtra("gender", apply.getGender());
                            intent.putExtra("from", apply.getFrom());
                            intent.putExtra("to", apply.getTo());
                            intent.putExtra("year",String.valueOf(apply.getYear()));
                            intent.putExtra("aadhaar", String.valueOf(apply.getAadhaarNo()));
                            intent.putExtra("mobile", String.valueOf(apply.getMobileNo()));
                            intent.putExtra("imageUrl", imageURL);

                            // Start the new activity
                            startActivity(intent);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(ViewDetails.this, "Error retrieving data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                });
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String previousChildName) {
                // Handle child changed event
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                // Handle child removed event
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String previousChildName) {
                // Handle child moved event
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ViewDetails.this, "Error retrieving child nodes: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}